package com.training.constant;

/**
 * @author payal.parate
 *
 */
public enum Role {
	/**
	 * 
	 */
	ADMIN,/**
	 * 
	 */
	USER
}
